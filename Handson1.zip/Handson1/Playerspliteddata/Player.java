package com.ddd;

public class Player {
	String name;
	String country;
	String skill;
	
	public void display(String data,String data1,String data2){
		name=data;
		country=data1;
		skill=data2;
		System.out.println("Name:"+ name);
		System.out.println("Country:"+country);
		System.out.println("skill:"+skill);
	}
	

}