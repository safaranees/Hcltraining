package com.hcl1;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
				Scanner sc=new Scanner(System.in);
				Event event=new Event();
				Exhibition exhibition=new Exhibition();
				StageEvent stageevent=new StageEvent();
				System.out.println("Enter the name of the event");
				String name=sc.nextLine();
				event.setName(name);
				System.out.println("enter the detail of the event");
				String detail=sc.nextLine();
				event.setDetail(detail);
				System.out.println("enter the owner name of the event");
				String ownerName=sc.nextLine();
				event.setOwnerName(ownerName);
				System.out.println("enter the type of event");
				System.out.println("1.exhibition");
				System.out.println("2.stageevent");
				int ch=sc.nextInt();
				if(ch==1) {
					System.out.println("Enter the number of stall");
					int noOfStall=sc.nextInt();
					exhibition.setNoOfStall(noOfStall);
					exhibition.projectedRevenue(noOfStall);
				}
				if(ch==2) {
					System.out.println("Enter the number of shows");
					int noOfShows=sc.nextInt();
					stageevent.setNoOfShows(noOfShows);
					System.out.println("Enter the number of seats per show");
					int noOfSeatsPerShow=sc.nextInt();
					stageevent.setNoOfSeatsPerSeconds(noOfSeatsPerShow);
					stageevent.projectedrevenue(noOfShows,noOfSeatsPerShow);
					
				}

			}

}
