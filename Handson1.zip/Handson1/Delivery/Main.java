package com.ccc;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Delivery del=new Delivery();
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the over");
		long over=sc.nextLong();
		System.out.println("Enter the ball");
		long ball=sc.nextLong();
		System.out.println("enter the run");
		long runs=sc.nextLong();
		System.out.println("enter the batsman");
		sc.nextLine();
		String batsman=sc.nextLine();
		System.out.println("enter the bowler");
		String bowler=sc.nextLine();
		System.out.println("enter the nonstriker");
		String nonstriker=sc.nextLine();
		del.displayDeliveryDetails(over,ball,runs,batsman,bowler, nonstriker);

	}

}
