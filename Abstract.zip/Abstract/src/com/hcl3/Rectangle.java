package com.hcl3;

	public class Rectangle extends Shape{
		float length;
		float breadth;
		
		public Double CalculatePerimeter() {
			double area=(length+breadth)*2;
			return area;

	}

		protected float getLength() {
			return length;
		}

		protected void setLength(float length) {
			this.length = length;
		}

		protected float getBreadth() {
			return breadth;
		}

		protected void setBreadth(float breadth) {
			this.breadth = breadth;
		}
		protected Rectangle(float length, float breadth) {
			super();
			this.length = length;
			this.breadth = breadth;
		}

		protected Rectangle() {
			super();
			
		}

}
