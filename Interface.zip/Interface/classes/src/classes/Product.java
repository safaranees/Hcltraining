package classes;

public class Product {
	int productid;
	String productname;
	double price;
	int stock;
	public int getProductid() {
		return productid;
	}
	public void setProductid(int productid) {
		this.productid = productid;
	}
	public String getProductname() {
		return productname;
	}
	public void setProductname(String productname) {
		this.productname = productname;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getStock() {
		return stock;
	}
	public void setStock(int stock) {
		this.stock = stock;
	}
	public void display(int productcode,String productname,double price,int stock) {
		System.out.println("Product code:"+productcode);
		System.out.println("Product name:"+productname);
		System.out.println("Price:"+price);
		System.out.println("stock:"+stock);
		
	}
	
	public void checkPrice(Product  p1,Product p2) {
		if(p1.price>p2.price) {
			System.out.println("TV is Cheaper than Mobilephone");
		}
		else {
			System.out.println("Mobilephone is Cheaper than TV");
		}
	}
}
