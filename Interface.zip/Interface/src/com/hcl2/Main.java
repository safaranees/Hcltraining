package com.hcl2;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		AxisBank axisbank=new AxisBank();
		System.out.println("Enter the duration");
		double duration=s.nextDouble();
		System.out.println("Enter the amount");
		double amount=s.nextInt();
		System.out.println("1) Axis Bank");
		System.out.println("2) HDFC Bank");
		System.out.println("3) ICICI Bank");
		System.out.println("Choose the Bank");
		int ch=s.nextInt();
		if(ch==1) {
			AxisBank ab=new AxisBank();
       	 	double total=(duration*amount*56)/100;
       	 	System.out.println("you will have return as"+total+"in"+duration+"years");
		}
		if(ch==2) {
			HDFC hc =new HDFC();
			double total=(duration*amount*56)/100;
       	 	System.out.println("you will have return as"+total+"in"+duration+"years");
		}
		if(ch==3) {
			ICICI icici=new ICICI();
			double total=(duration*amount*56)/100;
        	System.out.println("you will have return as"+total+"in"+duration+"years");
		}
	}

}
