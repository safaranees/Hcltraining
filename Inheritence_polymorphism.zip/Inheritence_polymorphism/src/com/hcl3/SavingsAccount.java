package com.hcl3;

public class SavingsAccount extends Account{
	double minimumBalance;
	public SavingsAccount() {
		super();
	}
	public SavingsAccount(String accountNo, double balance,String accountholdername,double minimumBalance) {
		super(accountNo,balance,accountholdername);
		this.minimumBalance = minimumBalance;
	}
	public double getMinimumBalance() {
		return minimumBalance;
	}
	public void setMinimumBalance(double minimumBalance) {
		this.minimumBalance = minimumBalance;
	}
	
}
