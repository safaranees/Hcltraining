package com.hcl5;

public interface Stall {
	void display();
}
