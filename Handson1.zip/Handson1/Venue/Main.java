package com.aaa;
import java.util.*;
public class Main {

	public static void main(String[] args) {
				Scanner sc=new Scanner(System.in);
				String name;
				String city;
				System.out.print("Enter the Venue name");
				sc.nextLine();
				name=sc.nextLine();
				System.out.print("Enter the city name");
				sc.nextLine();
				city=sc.nextLine();
				Venue venue=new Venue();
				venue.displayVenueDetails(name,city);
	

	}