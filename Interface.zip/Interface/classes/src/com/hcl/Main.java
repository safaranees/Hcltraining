package com.hcl;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner  sc=new Scanner(System.in);
		System.out.println("Enter the product code");
		int code=sc.nextInt();
		System.out.println("Enter the product name");
		String name=sc.nextLine();
		name=sc.nextLine();
		System.out.println("Enter price");
		double price=sc.nextDouble();
		System.out.println("Enter stock");
		int stock=sc.nextInt();
		
		System.out.println("Enter the product code");
		int code1=sc.nextInt();
		System.out.println("Enter the product name");
		String name1=sc.nextLine();
		name1=sc.nextLine();
		System.out.println("Enter price");
		double price1=sc.nextDouble();
		System.out.println("Enter stock");
		int stock1=sc.nextInt();
		
		Product p1=new Product(code,name,price,stock);
		Product p2=new Product(code1,name1,price1,stock1);
		
		p1.display(code,name,price,stock);
		p1.getDiscountedPrice(price);
		p1.checkPrice(p1,p2);
		
		p2.display(code1,name1,price1,stock1);
		p2.getDiscountedPrice(price1);
		p2.checkPrice(p1,p2);
		

	}

}
