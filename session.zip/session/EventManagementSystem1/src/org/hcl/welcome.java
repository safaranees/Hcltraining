package org.hcl;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/welcome")
public class welcome extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public welcome() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		String event=request.getParameter("eventName");
		pw.println("<h1>Event Management System</h1>");
		pw.println("<h3>welcome to this event </h3>"+event);
		pw.println("<form action='./display' method='get'>");
		pw.println("<input type='submit' value='Get Detail' name='submt'>");
		pw.println("</form>");
		HttpSession session=request.getSession();
		session.setAttribute("event", event);
		
	}

	

}
