package classes;

public class Main {

	public static void main(String[] args) {
			Product p1=new Product();
			Product p2=new Product();
			p1.display(1,"tv",50000.0,10);
			p2.display(2,"mobile",20000.0,20);
			p1.checkPrice(p1 ,p2);
			


	}

}
