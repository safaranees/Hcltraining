package com.hcl3;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String reverse= " ";
		System.out.println("Enter Humpty's Sentence:");
		String str1=sc.nextLine();
		int length = str1.length();
		for (int i = length - 1 ; i >= 0 ; i--) {
			reverse = reverse + str1.charAt(i);
		}
		System.out.println("Dumpty Says," + reverse);
	}

}

