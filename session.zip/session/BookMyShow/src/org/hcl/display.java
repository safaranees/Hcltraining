package org.hcl;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/display")
public class display extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public display() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		HttpSession seat = request.getSession();
		String seatType = (String) seat.getAttribute("event");
		HttpSession ticket = request.getSession();
		String ticketcount = (String) ticket.getAttribute("event");
		HttpSession cost = request.getSession();
		String ticketcost = (String) cost.getAttribute("event");
		pw.println("<h1>Ticket Booked Successfully</h1>");
		pw.println("<table border=1>");
		pw.println("<tr><th>Ticket Type</th><td>"+seatType+"</td></tr>");
		pw.println("<tr><th> Number ofTicket</th><td>"+ticketcount+"</td></tr>");
		pw.println("<tr><th>Ticket cost</th><td>"+ticketcost+"</td></tr>");
		pw.println("</table>");
		pw.close();
	}

	
	

}
