package com.hcl3;

public class Shivgath implements Fort{

	@Override
	public void distance() {
		// TODO Auto-generated method stub
		System.out.println("you are going to visit Shivgath");
		System.out.println("the distance is 100 km");
		
	}

}
