package com.hcl;

public class Product {
	int productcode;
	String productname;
	double price;
	int stock;
	String staticname;
	public Product() {
		 
	}
	
	public Product(int productcode, String productname, double price, int stock) {
		super();
		this.productcode = productcode;
		this.productname = productname;
		this.price = price;
		this.stock = stock;
	}

	public int getProductcode() {
		return productcode;
	}

	public void setProductcode(int productcode) {
		this.productcode = productcode;
	}

	public String getProductname() {
		return productname;
	}

	public void setProductname(String productname) {
		this.productname = productname;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getStock() {
		return stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}

	public String getStaticname() {
		return staticname;
	}

	public void setStaticname(String staticname) {
		this.staticname = staticname;
	}

	public void checkPrice(Product p1,Product p2) {
		if(p1.price<p2.price) {
			System.out.println(p1.getProductname()+"is Cheaper than "+p2.getProductname());
		}
		else {
			System.out.println(p2.getProductname()+" is Cheaper than"+p1.getProductname());
		}
	}
	
	public void display(int code,String name,double price,int stock) {
		System.out.println("Product details");
		System.out.println("product code:"+code);
		System.out.println("productname:"+name);
		System.out.println("Price:"+price);
		System.out.println("Stock:"+stock);
	}
	
	public void getDiscountedPrice(double price) {
		if(price>=80000) {
			double percent=0.3;
			double salesprice=price-(percent*price);
			System.out.println("Discounted Amount"+salesprice);
		}
		if(price>=60000) {
			double percent=0.2;
			double salesprice=price-(percent*price);
			System.out.println("Discounted Amount:"+salesprice);

			
		}
		if(price>=50000) {
			double percent=0.1;
			double salesprice=price-(percent*price);
			System.out.println("Discounted Amount:"+salesprice);

		}
		if(price<50000) {
			double percent=0.05;
			double salesprice=price-(percent*price);
			System.out.println("Discounted Amount:"+salesprice);

		}
		
	}

}
