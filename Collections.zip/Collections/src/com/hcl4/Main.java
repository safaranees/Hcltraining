package com.hcl4;

import java.util.Scanner;
import java.util.TreeSet;

public class Main {

	public static void main(String[] args) {
		TreeSet<String> t=new TreeSet<>();
		Scanner sc=new Scanner(System.in);
		
		boolean ab=true;
		int i=1;
		while(ab!=false && i!=0) {
			System.out.println("Enter the username:"+ " "+i);
			String str=sc.nextLine();
			t.add((str));
			System.out.println("Do you want to continue<(y/n):");
			String a=sc.nextLine();
			if(a.equals("y")) {
				ab=true;
				i++;
			}
			else {
				ab=false;
				i=0;
			}
		}
		System.out.println("The unique number of username is"+" "+t.size());


	}

}
