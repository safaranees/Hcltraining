package com.hcl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class jdbcDeletion {

	public static void main(String[] args) {
		Connection con=null;
		Statement st=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hcl","root","root");
			if(con!=null) {
				st=con.createStatement();
				int i=st.executeUpdate("Delete from emp where eno=5");
				if(i>0) {
					System.out.println("Successfully deleted");
				}
				else {
					System.out.println("Not Deleted");
				}
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}

}
