package com.hcl3;

	public class Square extends Shape {
		float side;
		public Double CalculatePerimeter() {
			double area=4*side;
			
			
			return area;
		
		

	}
		protected float getSide() {
			return side;
		}
		protected void setSide(float side) {
			this.side = side;
		}
		
		protected Square(float side) {
			super();
			this.side = side;
		}
		
		protected Square() {
			super();
			// TODO Auto-generated constructor stub
		}
	}

}
