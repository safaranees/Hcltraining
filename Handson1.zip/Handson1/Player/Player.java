package com.bbb;

public class Player {
	
	
	public void displayPlayerDetails(String name,String country,String skill) {
		
			System.out.print("player Details:\n");
			System.out.println("Player Name:"+ name);
			System.out.println("Country Name:"+ country);
			System.out.print("Skill:"+skill);

	}


}
