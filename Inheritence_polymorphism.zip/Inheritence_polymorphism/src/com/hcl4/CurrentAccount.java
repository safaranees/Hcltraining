package com.hcl4;

public class CurrentAccount extends Account {
	protected String tinNumber;
	public CurrentAccount() {
		super();
	}
	public CurrentAccount(String accName,String accNo,String bankName,String tinNumber) {
		super(accName,accNo,bankName);
		this.tinNumber = tinNumber;
	}

	public String getTinNumber() {
		return tinNumber;
	}

	public void setTinNumber(String tinNumber) {
		this.tinNumber = tinNumber;
	}
	public void display()
	{
		super.display();
		System.out.println("tin number:" +tinNumber);
	}
	
	
}
