package com.hcl5;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String says=sc.nextLine();
		System.out.println("Dumpty Says:"+says);
		System.out.println("What Humpty Want To Remove?");
		String remove=sc.nextLine();
		String newsentence= says.replaceAll(remove, "");
		System.out.println("Dumpty's New Sentense :"+ newsentence);
	}

}
