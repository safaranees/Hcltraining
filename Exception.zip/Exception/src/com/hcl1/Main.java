package com.hcl1;

import java.util.*;
public class Main {

	public static void main(String[] args) {
		Scanner s=new 	Scanner(System.in);
		System.out.println("Enter any 10 values");
		int a[]=new int[10];
		for(int i=0;i<a.length;i++) {
			a[i]=s.nextInt();
		}
		try {
			int k=10;
			for(int i=0;i<a.length;i++) {
			int divide=a[i]/k;
			System.out.println(divide);
			k--;
		}
		}
		catch(Exception e) {
				System.out.println(e);
			}
	
		System.out.println("Elements over");
		}

}


