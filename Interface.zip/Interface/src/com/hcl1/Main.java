package com.hcl1;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		Square square=new Square();
		Rectangle  rectangle=new Rectangle();
		System.out.println("Enter the Breadth and Length of Square");
		double breadth=s.nextDouble();
		rectangle.setBreadth(breadth);
		double length=s.nextDouble();
		rectangle.setLength(length);
		System.out.println("Enter the Side value");
		int side=s.nextInt();
		square.setSide(side);
		rectangle.calPeri();
		rectangle.calArea();
		square.calPeri();
		square.calArea();
	}

}
