package com.hcl5;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		List<String> list = new ArrayList<>();
		Scanner sc=new Scanner(System.in);
		boolean ab=true;
		while(ab!=false) {
			System.out.println("Enter the username:");
			String str=sc.nextLine();
			list.add((str));
			System.out.println("Do you want to continue(yes/no):");
			String a=sc.nextLine();
			if(a.equals("yes")) {
				ab=true;
			}
			else {
				ab=false;
			}
		}
		System.out.println("Number of user "+" "+list.size());

	}

}
