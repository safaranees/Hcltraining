package com.hcl2;

import java.util.*;

public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Humpty's Sentence");
		String str1=sc.nextLine();
		System.out.println("Enter Dumpty's Sentence");
		String str2=sc.nextLine();
		Boolean found = Arrays.asList(str1.split(" ")).contains(str2);
		if(found){
		      System.out.println("Found");
		}
		else {
			System.out.println("Not Found");
			
		}
	}

}
//Enter Humpty's Sentence : Can you see the wall? Shall we sit on a wall? Enter Dumpty's Sentence : wall Found
//Enter Humpty's Sentence : Can you see the wall? shall we sit on a wall? Enter Dumpty's Sentence : run Not Found
