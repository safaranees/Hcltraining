package com.hcl;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		ExtraType extraType=new ExtraType();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the extratype details");
		String extratype=sc.nextLine();
		String Details[]=extratype.split("#");
		extraType.display(Details[0], Details[1]);
	}

}
