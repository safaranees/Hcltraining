package com.hcl2;

import java.util.*;
public class Main {

	public static void main(String[] args) {
				Scanner s=new 	Scanner(System.in);
				System.out.println("Enter any 10 values");
				int a[]=new int[10];
				
				for(int i=0;i<a.length;i++) {
					a[i]=s.nextInt();
				}
				System.out.println("Enter the Divisor");
				int divisor=s.nextInt();
				try {
					for(int i=0;i<a.length;i++) {
					int divide=a[i]/divisor;
					System.out.println(divide);
				}
				}
				catch(Exception e) {
						System.out.println("Can't divide by zero");
					}
			
				System.out.println("Elements over");
				}

		

		


	}

