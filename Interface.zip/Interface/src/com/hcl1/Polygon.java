package com.hcl1;

public interface Polygon {
	public void calPeri();
	public void calArea();
	
}
