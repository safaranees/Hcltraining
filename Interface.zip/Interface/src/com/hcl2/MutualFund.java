package com.hcl2;

public interface MutualFund {
	public void duration();
	public void amount();
}
