package org.hcl.entities;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Test {

	public static void main(String[] args) {
		Configuration configuration=new Configuration();
		configuration.configure("hibernate.cfg.xml");
		SessionFactory factory=configuration.buildSessionFactory();
		Session session=factory.openSession();
		Transaction tx=session.beginTransaction();
		/*
		 * Student st=new Student(); st.setId(1); st.setName("aryan");
		 * st.setAddress("chennai"); st.setCourse("Java"); session.persist(st);
		 */
		Student st=session.load(Student.class, 1);
		System.out.println(st.getName()+"\t"+st.getAddress());
		tx.commit();
		session.close();
		factory.close();
	}

}
