package com.fff;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		long over,ball,runs;
		String batsman,bowler,nonStriker;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the over");
		over=sc.nextLong();
		System.out.println("Enter the ball");
		ball=sc.nextLong();
		System.out.println("Enter the runs ");
		runs=sc.nextLong();
		System.out.println("Enter the batsman");
		sc.nextLine();
		batsman=sc.nextLine();
		System.out.println("Enter the bowler");
		bowler=sc.nextLine();
		System.out.println("Enter the Nonstriker");
		nonStriker=sc.nextLine();
		Delivery delivery=new Delivery(over,ball,runs,batsman,bowler,nonStriker);
		System.out.println("over:"+delivery.getOver());
		System.out.println("ball:"+delivery.getBall());
		System.out.println("runs:"+delivery.getRuns());
		System.out.println("batsman:"+delivery.getBatsman());
		System.out.println("bowler:"+delivery.getBowler());
		System.out.println("nonstriker:"+delivery.getNonStriker());
	}

}
