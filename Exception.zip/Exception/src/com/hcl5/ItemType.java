package com.hcl5;

public class ItemType {
	String name;
	double deposit;
	double costpername;
	public ItemType() {
		
	}
	public ItemType(String name, double deposit, double costpername) {
		super();
		this.name = name;
		this.deposit = deposit;
		this.costpername = costpername;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getDeposit() {
		return deposit;
	}
	public void setDeposit(double deposit) {
		this.deposit = deposit;
	}
	public double getCostpername() {
		return costpername;
	}
	public void setCostpername(double costpername) {
		this.costpername = costpername;
	}
	
	void display(String name,double deposit,double CostperDay) {
		
		System.out.println("Name:"+name);
		System.out.println("deposit:"+deposit);
		System.out.println("Cost Per Day:"+CostperDay);
	}
}
