package com.hcl2;

public class Shape {
	double area;
	public void computeArea() {
		area=0;
	}
}
