package com.hcl3;

import java.util.*;

public class Main {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		Rajmachi rajmachi=new Rajmachi();
		Shivgath shivgath=new Shivgath();
		Murud murud=new Murud();
		System.out.println("what you want to visit");
		System.out.println("Rajmachi");
		System.out.println("Shivgath");
		System.out.println("Murud");
		String str=s.nextLine();
		if(str=="Rajmachi") {
			rajmachi.distance();
		}
		if(str=="Shivgath") {
			shivgath.distance();
		}
		if(str=="Murud") {
			murud.distance();
		}

	}

}
