window.onload=function(){
    const eventDetails=[];
    document.getElementById("add").addEventListener("click",addEvent);
    document.getElementById("display").addEventListener("click",displayEvent);
    let name=document.getElementById("eventName");
    let message=document.getElementById("Event_success_Message");
    let result=document.getElementById("result_table");

    function addEvent(){
        let eventname=name.value;
        result.innerHTML="";
        if(name===""){
            message.innerText="Please Enter an event name";
        }
        else{
            if(eventDetails.includes(eventname)){
                message.innerText="Event name already exists";
            }
            else{
                eventDetails.push(eventname);
                name.value="";
                message.innerText="Event name added successfully. Try with Some other name";
            }
        }
    }
    

    function displayEvent(){
        message.innerText="";
        if(eventDetails.length===0){
           result.innerHTML="<tr><td>There is no list to display</td></tr>"; 
        }
        else{
            let str = "<tr><th>Event Names</th></tr>"; 
            eventDetails.sort();
            for(let event of eventDetails){
               str += "<tr><td>" + event + "</td></tr>"; 
            }
            result.innerHTML = str; 
        }
    }
}

