package com.ddd;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		String str;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Player Details");
		str=sc.nextLine();
		String SplitedData[]=str.split(",");
		Player player=new Player();
		player.display(SplitedData[0],SplitedData[1],SplitedData[2]);
		}

}
