package com.hcl2;

public class Triangle {
	double base,height;
	public Triangle() {
		
	}
	public Triangle(double base, double height) {
		super();
		this.base = base;
		this.height = height;
	}

	public double getBase() {
		return base;
	}

	public void setBase(double base) {
		this.base = base;
	}

	public double getHeight() {
		return height;
	}

	public void setHeight(double height) {
		this.height = height;
	}

	public void computeArea() {
		double area=0.5*base*height;
		System.out.format("Triangle:"+area);
	}

}
