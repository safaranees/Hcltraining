package com.hcl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class JdbcInsert {

	public static void main(String[] args) {
		Connection con=null;
		Statement st=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hcl","root","root");
			if(con!=null) {
				st=con.createStatement();
				int i=st.executeUpdate("insert into emp (eno,name,address) values(3,'def','chennai')");
				if(i>0) {
					System.out.println("Successfully inserted");
				}
				else {
					System.out.println("Not inserted");
				}
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}

}
