package com.hcl3;

public class Rajmachi implements Fort{
	@Override
	public void distance() {
		// TODO Auto-generated method stub
		System.out.println("you are going to visit Rajmachi");
		System.out.println("the distance is 55 km");
		
	}

}
