package com.hcl;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Car s=new Service();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your car number");
		int carNumber=sc.nextInt();
		System.out.println("How many years old car do you have");
		int years=sc.nextInt();
		System.out.println("Car Brand");
		String brand=sc.nextLine();
		brand=sc.nextLine();
		s.sum( carNumber);
		s.brand(brand);
        s.years(years);
		

	}

}
