package com.hcl1;

public class Square implements Polygon{
	double side;
	public Square() {
		super();
	}
	public Square(double side) {
		super();
		this.side = side;
	}
	public double getSide() {
		return side;
	}
	public void setSide(double side) {
		this.side = side;
	}
	public void calcPeri(int side) {
		int perimeter=4*side;
		System.out.println("Perimeter of Square"+perimeter);
	}
	public void calcArea(int side) {
		int area=side*side;
		System.out.println("Area of Square"+area);
	}

}
