package com.hcl3;

import java.util.*;
public class Main {
			
public static void main(String[] args)  {
			Scanner sc=new Scanner(System.in);
			System.out.println("");
			Circle cc= new Circle();
			Rectangle rect=new Rectangle();
			Square sq=new Square();
			int n=0;
			System.out.println("Enter the Choice");
			int ch=sc.nextInt();
			if(ch==1) {
				System.out.println("\nenter the radius  ");
	            double rad=sc.nextDouble();
	            cc.setRadius(rad);
	            System.out.format("\nThe perimeter of the circle %.2f",cc.CalculatePerimeter());
	            sc.nextLine();
			}
			if(ch==2) {
				System.out.println("\nenter the length of the rectangle   ");
	            float len=sc.nextFloat();
	            rect.setLength(len);
	            System.out.println("\nenter the breadth of the rectangle   ");
	            float bread=sc.nextFloat();
	            rect.setBreadth(bread);
	            System.out.format("\nThe perimeter of the rectangle%.2f",rect.CalculatePerimeter());
	            sc.nextLine();
			}
			if(ch==3) {
				System.out.println("\nenter the side of the square  ");
	            float sqt=sc.nextFloat();
	            sq.setSide(sqt);
	            System.out.format("\nThe perimeter of the square%.2f",cc.CalculatePerimeter());

			}

	}

}
