package com.hcl;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

public class JdbcExample {

	public static void main(String[] args) {
		Connection con=null;
		Statement st=null;
		ResultSet rs=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hcl","root","root");
			if(con!=null) {
				st=con.createStatement();
				rs=st.executeQuery("select * from emp");
				while(rs.next())
				System.out.println(rs.getInt(1)+"\t"+rs.getString(2)+"\t"+rs.getString(3));
				//System.out.println("Connection Established");
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}

}
