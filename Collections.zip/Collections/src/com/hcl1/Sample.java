package com.hcl1;

public class Sample {
	public String username;
	   

    public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}
	 public Sample (String name)
	    {
	        username = name;
	   
	    }

	    public String toString ()
	    {
	       return username;
	    }
}
