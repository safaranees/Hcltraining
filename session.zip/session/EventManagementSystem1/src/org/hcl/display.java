package org.hcl;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/display")
public class display extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public display() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		//String eventname=request.getParameter("eventName");
		HttpSession event1 = request.getSession();
		String eventname = (String) event1.getAttribute("event");
		pw.println("<h1>Event Management System</h1>");
		pw.println("<h3>Event</h3>"+eventname);
		pw.println("<h3> is planned to be held on 2018-09-05 in Rudolfinam</h3>");
		pw.close();
	}

	

}
