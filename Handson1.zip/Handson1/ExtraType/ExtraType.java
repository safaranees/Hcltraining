package com.hcl;

public class ExtraType {
	String name;
	long runs;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getRuns() {
		return runs;
	}
	public void setRuns(long runs) {
		this.runs = runs;
	}
	
	public void display(String str1,String str2) {
		name=str1;
		runs=Long.parseLong(str2);
		System.out.println("ExtraType Details");
		System.out.println("Name:"+name);
		System.out.println("runs:"+runs);
	}

}
