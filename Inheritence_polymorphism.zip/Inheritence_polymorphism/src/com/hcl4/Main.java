package com.hcl4;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("Choose Account Type");
		System.out.println("1.Savings Account");
		System.out.println("2.Current Account");
		int ch=s.nextInt();
		if(ch==1) {
			System.out.println("Enter Account details in comma separated(Account Name,Account Number,Bank Name,Organisation Name)");
			s.nextLine();
       	 	String str=s.nextLine();
       	 	String [] data=str.split(",");
       	 	for(String de:data) 
       	 		System.out.println(" ");
       	 	SavingsAccount savingsaccount=new SavingsAccount(data[0],data[1],data[2],data[3]);
			savingsaccount.display();
		}
		if(ch==2) {
			System.out.println("Enter Account details in comma separated(Account Name,Account Number,Bank Name,Organisation Name");
			s.nextLine();
       	 	String str=s.nextLine();
       	 	String [] data=str.split(",");
       	 	for(String de:data) 
       	 		System.out.println(" ");
       	 	CurrentAccount currentaccount=new CurrentAccount(data[0],data[1],data[2],data[3]);
       	 	currentaccount.display();
		}
	}

}
