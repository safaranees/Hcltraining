package com.hcl2;

public class ICICI implements MutualFund{

	@Override
	public void duration() {
		// TODO Auto-generated method stub
		 System.out.println("Enter the tenure of SIP");
	}

	@Override
	public void amount() {
		// TODO Auto-generated method stub
		System.out.println("Enter the Amount of Interest");
	}

}
