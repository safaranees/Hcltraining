package org.hcl;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/display")
public class Display extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public Display() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request,response);
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		String name=request.getParameter("name");
		String phone_number=request.getParameter("phone");
		String email=request.getParameter("email");
		String city=request.getParameter("city");
		pw.println("<table>");
		pw.println("<tr><td>Name</td><td>"+name+"</td></tr>");
		pw.println("<tr><td>Phone number</td><td>"+phone_number+"</td></tr>");
		pw.println("<tr><td>Email</td><td>"+email+"</td></tr>");
		pw.println("<tr><td>City</td><td>"+city+"</td></tr>");
		pw.println("</table>");
		pw.close();
	}

}
