package com.hcl1;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) { 
		ArrayList<Sample> al= new ArrayList<>();
		Scanner sc=new Scanner(System.in);
		boolean b=true;
		int j=1;
		while(b!=false && j!=0) {
			System.out.println("Enter the username:"+ " "+j);
			String str=sc.nextLine();
			al.add(new Sample(str));
			System.out.println("Do you want to continue<(y/n):");
			String a=sc.nextLine();
			if(a.equals("y")) {
				b=true;
				j++;
			}
			else {
				b=false;
			}
		}
		
		System.out.println("Names Entered:");
		System.out.println(al.get(0));
		System.out.println(al.get(1));
		
		
	}

}
