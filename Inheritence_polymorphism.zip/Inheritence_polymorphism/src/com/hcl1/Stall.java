package com.hcl1;

public class Stall {
	String name;
	String detail;
	String ownername;
	public Stall() {
		
	}
	public Stall(String name, String detail, String ownername) {
		super();
		this.name = name;
		this.detail = detail;
		this.ownername = ownername;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDetail() {
		return detail;
	}
	public void setDetail(String detail) {
		this.detail = detail;
	}
	public String getOwnername() {
		return ownername;
	}
	public void setOwnername(String ownername) {
		this.ownername = ownername;
	}
	public Double computeCost(String stallType,Integer squareFeet) {
		if(stallType.equals("platinum")) {
			double sqft =squareFeet*200;
			return sqft;
			
		}
		if(stallType.equals("gold")) {
			double sqft1=squareFeet*100;
			return sqft1;
		
		}
		else{
			double sqft1=squareFeet*150;
			return sqft1;
		}
		
	
		
	}


	public Double computeCost(String stallType,Integer squareFeet,Integer NumberofTv) {
		double sqft=0;
		double total=0;
		if(stallType.equals("platinum")) {
			 sqft =squareFeet*200;
		
		}
		else if(stallType.equals("gold")) {
			 sqft=squareFeet*100;
		}
		else {
			 sqft=squareFeet*150;
			
		
		}
	
		total=sqft+(NumberofTv*10000);
		return total;
		
	}
	
		
		
	
}
	

