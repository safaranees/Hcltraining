package org.hcl.entities;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Test {

	public static void main(String[] args) {
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JpaEx1");
		EntityManager em=factory.createEntityManager();
		Emp e=new Emp();
		e.setName("ram");
		e.setAddress("hyd");
		em.persist(e);
		//em.getTransaction().commit();
		//em.clear();
		factory.close();
	}

}
