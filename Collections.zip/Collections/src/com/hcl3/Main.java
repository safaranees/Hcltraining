package com.hcl3;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		ArrayList<String> al=new ArrayList<>();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of halls");
		int  numberofStall=sc.nextInt();
		sc.nextLine();
		for(int i=1;i<=numberofStall;i++) {
			System.out.println("Enter the hall name");
			al.add(sc.nextLine());
		}
		System.out.println("Enter the hall name to be searched");
		String searchname=sc.nextLine();
		if(al.contains(searchname)==true)
			System.out.println(searchname+ "is found at position "+al.indexOf(searchname));
		else
			System.out.println(searchname+"hall is not found");

	}

}
