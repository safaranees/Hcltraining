package com.hcl7;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Humpty's Sentences:");
		String humty=sc.nextLine();
		System.out.println("Enter Dumpty's Sentences:");
		String dumpty=sc.nextLine();
		int wordlen1= humty.split(" ").length;
		int wordlen2= dumpty.split(" ").length;
		if(wordlen1==wordlen2) {
			System.out.println("Both have used equal number of words");
		}
		else if(wordlen1>wordlen2){
			System.out.println("Humpty has used more words");
		}
		else {
			System.out.println("Dumpty has used more words");
		}
	}

}
//Enter Humpty's Sentence : This my sample data Enter Dumpty's Sentence : This is my example Both have used equal number of words
//Enter Humpty's Sentence : You are great Enter Dumpty's Sentence :