package com.hcl3;

public class Murud implements Fort{

	@Override
	public void distance() {
		System.out.println("you are going to visit Murud");
		System.out.println("the distance is 93km");
		
	}

}
