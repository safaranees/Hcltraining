package com.hcl2;

import java.util.*;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

        Scanner sc=new Scanner(System.in);
        Shape shape=new Shape();
        Rectangle rectangle=new Rectangle();
        Triangle triangle=new Triangle();
        Circle circle=new Circle();
        System.out.println("Enter the shape");
        System.out.println("1.Circle");
        System.out.println("2.Rectangle");
        System.out.println("3.Triangle");
        int ch=sc.nextInt();
        if(ch==1) {
        	System.out.println("Enter the radius");
            double radius=sc.nextDouble();
            sc.hasNextLine();
            circle.setRadius(radius);
            circle.computeArea();
        }
        if(ch==2) {
        	System.out.println("Enter the length and breadth");
            double length=sc.nextDouble();
            rectangle.setLength(length);
            double breadth=sc.nextDouble();
            rectangle.setBreadth(breadth);
            rectangle.computeArea();
        }
        if(ch==3) {
        	 System.out.println("Enter the base and height");
             double base =sc.nextDouble();
             triangle.setBase(base);
             double ht=sc.nextDouble();
             triangle.setHeight(ht);
             triangle.computeArea();
        }
        if(ch>=4) {
        	System.out.println("Invalid Choice");
        }
	}

}
