package com.hcl3;

import java.util.*;
public class Main {
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the cost of the item for n days");
		int n_days=sc.nextInt();
		System.out.println("�nter the value of n");
		int n=sc.nextInt();
		
		try {
			int divide=n_days/n;
			System.out.println("cost per day of the item is"+divide);

		}
		catch(Exception e){
			e.printStackTrace();
		}

	}

}
