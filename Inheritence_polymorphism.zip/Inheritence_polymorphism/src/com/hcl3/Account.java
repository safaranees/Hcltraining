package com.hcl3;

public class Account {
	String Accountno;
	double balance;
	String accountHolderName;
	public Account() {
		super();
	}
	public Account(String accountno, double balance, String accountHolderName) {
		super();
		Accountno = accountno;
		this.balance = balance;
		this.accountHolderName = accountHolderName;
	}
	public String getAccountno() {
		return Accountno;
	}
	public void setAccountno(String accountno) {
		Accountno = accountno;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public String getAccountHolderName() {
		return accountHolderName;
	}
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	
}
