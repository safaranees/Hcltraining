package com.hcl1;

	public class StageEvent extends Event{
		int noOfShows;
		int noOfSeatsPerSeconds;
		public StageEvent() {
			
		}
		public int getNoOfShows() {
			return noOfShows;
		}
		public void setNoOfShows(int noOfShows) {
			this.noOfShows = noOfShows;
		}
		public int getNoOfSeatsPerSeconds() {
			return noOfSeatsPerSeconds;
		}
		public void setNoOfSeatsPerSeconds(int noOfSeatsPerSeconds) {
			this.noOfSeatsPerSeconds = noOfSeatsPerSeconds;
		}
		public StageEvent(int noOfShows, int noOfSeatsPerSeconds) {
			super();
			this.noOfShows = noOfShows;
			this.noOfSeatsPerSeconds = noOfSeatsPerSeconds;
		}
		
		public void projectedrevenue(int noOfShows,int noOfSeatsPerShow) {
			double events=50*noOfShows*noOfSeatsPerShow;
			System.out.println("The projected revenue of that event is"+"  "+events);
			
		}

	

}
