package com.eee;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String name;
		String city;
		System.out.print("Enter the Venue name");
		sc.nextLine();
		name=sc.nextLine();
		System.out.print("Enter the city name");
		sc.nextLine();
		city=sc.nextLine();
		Venue venue=new Venue();
		venue.display(name, city);
		boolean  i=true;
		while(i!=false) {
		System.out.println("Verify and Update Venue Details\n");
		System.out.println("Menu\n");
		System.out.println("1.Update Venue Name\n");
		System.out.println("2.Update City Name\n");
		System.out.println("3.All information Correct/Exit");
		System.out.println("Type  1 or 2 or 3");
		int ch=sc.nextInt();
		if(ch==1) {
			System.out.println("Enter the Venue Name");
			sc.nextLine();
			name=sc.nextLine();
			venue.setName(name);
			venue.setCity(city);
			venue.display(name,city);
			i=true;
		}
		if(ch==2) {
			System.out.println("Enter the City Name");
			sc.nextLine();
			city=sc.nextLine();
			venue.setName(name);
			venue.setCity(city);
			venue.display(name,city);
			i=true;
			}
		if(ch==3) {
			venue.display(name, city);
			i=false;
			break;
		}
	}
}
}
