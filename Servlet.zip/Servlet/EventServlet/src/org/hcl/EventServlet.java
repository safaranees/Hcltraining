package org.hcl;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/index")
public class EventServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public EventServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		pw.println("<h1> Welcom to Hall Paradise</h1>");
		pw.println("<p>The Types of Event are;</p>");
		pw.println("<ul>");
		pw.println("<li>Exhibition</li>");
		pw.println("<li>Stage Show</li>");
		pw.println("</ul>");
		pw.close();
	}

}
