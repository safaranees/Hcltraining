package com.hcl5;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		try {
			System.out.println("Enter the item type details");
			System.out.println("Enter the Name");
			String name=s.nextLine();
			System.out.println("Enter the deposit");
			double deposit=s.nextDouble();
			System.out.println("Enter the CostperDay");
			double CostperDay=s.nextDouble();
			ItemType itemtype=new ItemType();
			itemtype.display(name, deposit, CostperDay);
		}
		catch(NumberFormatException nfe) {
			System.out.println(nfe.toString());
		}
		

	}

}
