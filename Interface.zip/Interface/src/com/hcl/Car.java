package com.hcl;

public interface Car {
	public void sum(int carNumber);
	public void years(int years);
	public void brand(String brand);

}
