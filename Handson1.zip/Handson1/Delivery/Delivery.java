package com.ccc;

public class Delivery {
	long over;
	long ball;
	long runs;
	String batsman;
	String bowler;
	String nonStriker;
		
	public void displayDeliveryDetails(long x,long y,long z,String str1,String 
			str2,String str3){
		over=x;
		ball=y;
		runs=z;
		batsman=str1;
		bowler=str2;
		nonStriker=str3;
		System.out.append("Delivery Details:\n");
		System.out.print("over:"+ over+"\n ");
		System.out.print("Ball:"+ball+"\n ");
		System.out.print("Runs:"+runs+"\n ");
		System.out.print("Batsman:"+batsman+" \n");
		System.out.print("Bowler:"+bowler+"\n ");
		System.out.print("NonStriker:"+nonStriker);
	}

}
