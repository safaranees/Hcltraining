import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Humpty's Sentence :");
		String str=sc.nextLine();
		String convertedString=str.toUpperCase();
		System.out.println("Converted String :"+ convertedString);
		
	}

}
//Enter Humpty's Sentence : i am a good boy Converted String : I AM A GOOD BOY