package com.hcl1;

import java.util.*;
public class Main {

	public static void main(String[] args) {

        Scanner sc=new Scanner(System.in);
        Stall stall=new Stall();
        System.out.println("Enter the name of the stall");
        String s=sc.nextLine();
        stall.setName(s);
        System.out.println("Enter the detail of the stall");
        String s0=sc.nextLine();
        stall.setDetail(s0);
        System.out.println("Enter the owwner name of the stall");
        String s1=sc.nextLine();
        stall.setOwnername(s1);
        System.out.println("Enter the Type of the stall");
        String s2=sc.nextLine();
        System.out.println("Enter the  size of the stall in sqarefeet");
        Integer squareFeet=sc.nextInt();
        System.out.println("Does the stall have Tv?(y/n)");
        sc.nextLine();
        String s3=sc.next();
        if(s3.equals("y")) {
        	System.out.println("Enter number of Tv");
        	int num=sc.nextInt();
        	double d=stall.computeCost(s2, squareFeet, num);
        	System.out.println("the cost of the stall is"+d);
        }
        else {
        	double a=stall.computeCost(s2,squareFeet);
        }

	}

}
