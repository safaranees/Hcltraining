package org.hcl;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/index")
public class index extends HttpServlet {
	private static final long serialVersionUID = 1L;

    
    public index() {
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		pw.println("<h1>Book My Show</h1>");
		pw.println("<form action='./confirm' method='get'>");
		pw.println("<label>Select Event type</label>");
		pw.println("<select name='seatType'");
		pw.println("<option value='others'>others</option>");
		pw.println("<option value='platinum'>platinum</option>");
		pw.println("<option value='gold'>gold</option>");
		pw.println("</select>");
		pw.println("<br>");
		pw.println("Enter the number of ticket: <input type='text' name='ticketCount'>");
		pw.println("<br>");
		pw.println("<input type='submit' value='Book Ticket' name='submit'>");
		pw.println("</form>");
		pw.println("</form>");
		pw.close();
	}

	
	

}
