package com.hcl6;

import java.util.Scanner;

import com.hcl5.ItemType;

public class Main {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		try {
			System.out.println("Enter the integer input");
			int integer=s.nextInt();
			System.out.println("Enter value is "+integer);
		}
		catch(Exception nfe) {
			System.out.println(nfe.toString());
		}

	}

}
