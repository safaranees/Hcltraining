package com.hcl;

public class Service implements Car{
	public void sum(int CarNumber) {
		int sum=0;
		while(CarNumber!=0) {
			sum=sum+CarNumber%10;
			CarNumber=CarNumber/10;
			
		}
		if(sum%2==0)
		{
			System.out.println("you can come on Tuesday, Thursday or Saturday");
		}
		else {
			System.out.println("you can come on Monday,Wednesday,Friday or Sunday ");
		}
	}
	public void years(int years) {
		if(years>5) {
			System.out.println("You are Eligible for Free Washing");
			
		}
		else {
			System.out.println("You are not eligible for Free Washing");
		}
		
	}
	public void brand(String brand ) {
		
		if(brand.equals("Maruthi")) {
			double percent=0.05;
			double diff=percent*5000;
			double discountedAmount=5000-diff;
			System.out.println("Your Service Charges are"+discountedAmount);
			
		}
	}
}
