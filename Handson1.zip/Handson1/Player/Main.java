package com.bbb;
import java.util.*;
public class Main {

	public static void main(String[] args) {
			Scanner sc=new Scanner(System.in);
			String name;
			String country;
			String skill;
			System.out.print("Enter the player name ");
			sc.nextLine();
			name=sc.nextLine();
			System.out.print("Enter the country name");
			sc.nextLine();
			country=sc.nextLine();
			System.out.append("Enter the skill");
			sc.nextLine();
			skill=sc.nextLine();
			Player player=new Player();
			player.displayPlayerDetails(name, country, skill);

	}

}
