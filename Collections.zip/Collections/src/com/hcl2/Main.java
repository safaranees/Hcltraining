package com.hcl2;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		ArrayList<Itemtype> al= new ArrayList<>();
		Scanner sc=new Scanner(System.in);
		boolean b=true;
		int j=1;
		while(b!=false && j!=0) {
			System.out.println("Enter the details of Item"+ " "+j);
			System.out.println("Name:");
			String name=sc.nextLine();
			System.out.println("Deposit:");
			double deposit=sc.nextDouble();
			System.out.println("Cost per Day:");
			double cost=sc.nextDouble();
			al.add(new Itemtype(name,deposit,cost));
			System.out.println("Do you want to continue<(y/n):");
			String a=sc.nextLine();
			a=sc.nextLine();
			if(a.equals("y")) {
				b=true;
				j++;
			}
			else {
				b=false;
			}
		}
		
		System.out.println("Name"+"\t"+"deposit"+"\t"+"Cost per day");
		System.out.println(al.get(0));
		System.out.println(al.get(1));
	}

}
