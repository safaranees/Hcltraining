package com.hcl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class JdbcPreparedStatements {

	public static void main(String[] args) {
		Connection con=null;
		//PreparedStatement pst=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hcl","root","root");
			//String sql="insert into emp (eno,name,address) values(?,?,?)";
			if(con!=null) {
				
				PreparedStatement pst=con.prepareStatement("insert into emp (eno,name,address) values(?,?,?)");
				//pst=con.prepareStatement(i);
				pst.setInt(1, 6);
				pst.setString(2, "vbn");
				pst.setString(3, "chennai");
				System.out.println(pst);
				pst.executeUpdate();
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
}
