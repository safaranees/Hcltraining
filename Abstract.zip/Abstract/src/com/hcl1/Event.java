package com.hcl1;

	public class Event {
		String name;
		String detail;
		String OwnerName;
		public Event() {
			super();
		}
		public Event(String name, String detail, String ownerName) {
			super();
			this.name = name;
			this.detail = detail;
			OwnerName = ownerName;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getDetail() {
			return detail;
		}
		public void setDetail(String detail) { 
			//revenue=sales * average price of service or sales price
			this.detail = detail;
		}
		public String getOwnerName() {
			return OwnerName;
		}
		public void setOwnerName(String ownerName) {
			OwnerName = ownerName;
		}
		
		public int projectedMethod() {
			return 0;
			
		}

}
