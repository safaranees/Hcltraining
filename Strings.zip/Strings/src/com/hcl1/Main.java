package com.hcl1;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Hummy's sentences");
		String str1=sc.nextLine();
		System.out.println("Enter the Dummy's sentences");
		String str2=sc.nextLine();
		System.out.println("Concatenated Strings:");
		System.out.println(str1+"."+str2);
	}	

}
