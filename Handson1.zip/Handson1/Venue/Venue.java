package com.aaa;

public class Venue {
	String name;
	String city;
	public void displayVenueDetails(String str1, String str2) {
			name=str1;
			city=str2;
			System.out.print("Venue Details:");
			System.out.println("  ");
			System.out.println("Venue Name:"+ name);
			System.out.println("City Name:"+ city);
		}

	}


