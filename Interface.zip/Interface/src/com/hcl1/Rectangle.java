package com.hcl1;

public  class Rectangle implements Polygon {
	double length;
	double Breadth; 
	public Rectangle() {
		super();
	}
	public Rectangle(double length, double breadth) {
		super();
		this.length = length;
		Breadth = breadth;
	}
	
	public double getLength() {
		return length;
	}

	public void setLength(double length) {
		this.length = length;
	}

	public double getBreadth() {
		return Breadth;
	}

	public void setBreadth(double breadth) {
		Breadth = breadth;
	}

	public void calcPeri(double breadth,double length) {
		double perimeter=2*(breadth+length);
		System.out.println("the perimeter of Rectangle"+perimeter);
	}
	public void calcArea(double breadth,double length) {
		double area=breadth*length;
		System.out.println("The area of the Rectangle is"+area);
	}
	
	
}
