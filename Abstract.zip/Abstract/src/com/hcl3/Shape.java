package com.hcl3;

public abstract class Shape {

	public abstract Double calculatePerimeter();

}
