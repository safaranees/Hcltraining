package com.hcl3;

public interface Fort {
	public void distance();

}
