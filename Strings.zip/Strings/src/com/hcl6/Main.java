package com.hcl6;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Humpty's Sentences:");
		String humty=sc.nextLine();
		System.out.println("Humpty says:"+humty);
		System.out.println("What Dumpty want to insert & where?");
		String insert1=sc.nextLine();
		
		System.out.println("Enter position:");
		int position=sc.nextInt();
		StringBuffer stringbuffer = new StringBuffer(humty);
		stringbuffer.insert(position,insert1);

		System.out.println("Humpty's New Sentense :"+stringbuffer);
		
	}

}
/*Enter Humpty's Sentence : 
you are a boy 
Humpty Says : 
	you are a boy 
	What Dumpty want to insert & where? 
			good 
			Enter Position : 
				11 
				Humpty's New Sentense :you are a good boy
				StringBuffer sb = new StringBuffer("abcdefghijk");
      sb.insert(3, "123");
      System.out.println(sb); 
   
				*/
