package org.hcl;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/confirm")
public class confirm extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public confirm() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		String seatType=request.getParameter("seatType");
		String ticket=request.getParameter("ticketCount");
		int count=Integer.parseInt(ticket);
		int ticketcount=1000*count;
		pw.println("<h1>Ticket Confirmation</h1>");
		pw.println("<h3>The total cost is</h3>"+ticketcount);
		pw.println("<h3>Do you want to confirm your ticket?</h3>");
		pw.println("<form action='./display' method='get'><br>");
		pw.println("<input type='submit' value='Confirm' name='submit' id='confirm'>");
		pw.println("<input type='submit' value='Cancel' name='submit'  id='cancel'>");
		pw.println("</form>");
		if(ticketcount!=0)
		{
			RequestDispatcher rd=request.getRequestDispatcher("display.java");
			HttpSession session=request.getSession();
			session.setAttribute("seatType", seatType);
			session.setAttribute("Ticketcount", ticket);
			session.setAttribute("cost", ticketcount);
			rd.forward(request, response);
		}
		else
		{
			pw.println("<p>Ticket Canceled</p>");
			RequestDispatcher rd=request.getRequestDispatcher("index.java");
			rd.include(request, response);
			
		}
		pw.close();
	}

	

}
