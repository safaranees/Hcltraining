package com.hcl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class jdbc2 {
	static boolean result; 
	public static void main(String[] args) {
		String driver="sunjdbc.odbc.JdbcOdbcDriver";
		String cs="jdbc:odbc:mydsn";
		try {
			Class.forName(driver);
			System.out.println("driver is loaded");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hcl","root","root");
			System.out.println("jdbc client connected to oravle server");
			Statement st=con.createStatement();
			System.out.println("------"+st);
			System.out.println("Hello");
			result=st.execute("drop table emp");
			System.out.println(result);
			if(result)
				System.out.println("failed in dropping a table");
			else
				System.out.println("table deleted");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
