package com.hcl3;

import java.util.*;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		FixedAccount fixedaccount=new FixedAccount();
    	System.out.println("Enter the Account details");
        String s=sc.nextLine();
        String [] data=s.split(",");
    	for(String da:data) 
    		System.out.println(" ");
    	String name=data[0];
  	    fixedaccount.setAccountno(name);
  	    String bal= data[1];
  	    double balance= Double.parseDouble(bal);
  	    fixedaccount.setBalance(balance);
  	    String AccountholderName=data[2];
  	    fixedaccount.setAccountHolderName(AccountholderName);
  	    String mb=data[3];
  	    double minimumbalance=Double.parseDouble(mb);
  	    fixedaccount.setMinimumBalance(minimumbalance);
  	    String lp=data[4];
  	    Integer lockingperiod=Integer.parseInt(lp);
  	    fixedaccount.setLocking_period(lockingperiod);
  	    fixedaccount.display();
	}

}
