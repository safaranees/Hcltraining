package com.hcl3;

public class FixedAccount extends SavingsAccount{
	private Integer lockingperiod;
	public FixedAccount() {
		super();
	}

	public FixedAccount(String accountNo, double balance, String accountHolderName,double minimumBalance,Integer lockingperiod) {
		super(accountNo, balance, accountHolderName, minimumBalance);
		this.lockingperiod = lockingperiod;
	}

	public Integer getLocking_period() {
		return lockingperiod;
	}

	public void setLocking_period(Integer locking_period) {
		this.lockingperiod = locking_period;
	}
	
	void display() {
		System.out.println("Account details");
		System.out.println("AccountNumber\t Bank Account Holder Name\t Minimum Balance\t Locking Period");
		System.out.println(Accountno+"\t"+balance+"\t"+accountHolderName+"\t"+minimumBalance+"\t"+lockingperiod);
	}

	
}
