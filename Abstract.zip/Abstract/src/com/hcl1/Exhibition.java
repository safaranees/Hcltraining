package com.hcl1;

	public class Exhibition extends Event{
		int noOfStall;
		public Exhibition () {
			super();
		}

		public Exhibition(int noOfStall) {
			super();
			this.noOfStall = noOfStall;
		}

		public int getNoOfStall() {
			return noOfStall;
		}

		public void setNoOfStall(int noOfStall) {
			this.noOfStall = noOfStall;
		}

		public void projectedRevenue(double noOfStall ) {
			double revenue=noOfStall*10000;
			System.out.println("The projected revenue of that event is"+" "+revenue);
		}

}
