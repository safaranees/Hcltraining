package com.hcl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.Scanner;

import com.mysql.cj.jdbc.Driver;

public class jdbc1 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		Connection con=null;
		Statement st=null;
		String url="jdbc:mysql://localhost:3306/hcl";
		String username="root";
		String pwd="root";
		try {
			Driver d=new Driver();
			DriverManager.registerDriver(d);
			con=DriverManager.getConnection(url,username,pwd);
			if(con!=null) {
				st=con.createStatement();
				int eno=sc.nextInt();
				String name=sc.nextLine();
				String address=sc.nextLine();
				int i=st.executeUpdate("insert into emp (eno,name,address) values("+eno+",'"+name+"','"+address+"')");
				if(i>0) {
					System.out.println("Successfully inserted");
				}
				else {
					System.out.println("Not inserted");
				}
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}

	}

}
