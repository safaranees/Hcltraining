package com.hcl5;

import java.util.*;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
	    GoldStall goldstall=new GoldStall();
	    PremiumStall premiumstall=new PremiumStall();
	    ExecutiveStall executivestall=new ExecutiveStall();
	    System.out.println("Enter the Choose Type ");
		System.out.println("1) Gold Stall");
		System.out.println("2) Perimium Stall");
		System.out.println("3) Executive Stall");
		System.out.println("Enter the Choice");
	    int ch=sc.nextInt();
	    if(ch==1) {
            System.out.println("Enter the stall details in comma separated by comma(StallName,StallCost,OwnerName,NooftvSets)");
            String details=sc.nextLine();
            String [] str=details.split(",");
            for(String de:str)
            	System.out.println(" ");
            String sname=str[0];
            goldstall.setStallName(sname);
            Integer scost=Integer.parseInt(str[1]);
            goldstall.setCost(scost);
            String OwnerName=str[2];
            goldstall.setOwnerName(OwnerName);
            Integer Tvsets=Integer.parseInt(str[3]);
            goldstall.setTvSet(Tvsets);
            goldstall.display();
	    }
	    if(ch==2) {
	    	sc.nextLine();
            System.out.println("Enter the stall details in comma separated by comma(StallName,StallCost,OwnerName,No Of Projectors)");
            String details1=sc.nextLine();
            String [] str1=details1.split(",");
            for(String de:str1)
            	System.out.println(" ");
            String sname1=str1[0];
            premiumstall.setStallName(sname1);;
            Integer scost1=Integer.parseInt(str1[1]);
            premiumstall.setCost(scost1);
            String OwnerName1=str1[2];
            premiumstall.setOwnerName(OwnerName1);
            Integer projectors=Integer.parseInt(str1[3]);
            premiumstall.setProjector(projectors);
            premiumstall.display();
	    }
	    if(ch==3) {
	    	sc.nextLine();
            System.out.println("Enter the stall details in comma separated by comma(StallName,StallCost,OwnerName,NoofScreens)");
            String details2=sc.nextLine();
            String [] str2=details2.split(",");
            for(String de:str2)
            	System.out.println(" ");
            String sname2=str2[0];
            executivestall.setStallName(sname2);
            Integer scost2=Integer.parseInt(str2[1]);
            executivestall.setCost(scost2);
            String OwnerName2=str2[2];
            executivestall.setOwnerName(OwnerName2);
            Integer screen=Integer.parseInt(str2[3]);
            executivestall.setScreen(screen);
            executivestall.display();
	    }
	}
}
